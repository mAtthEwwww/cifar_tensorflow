请先阅读已经生成的PatternRecognition.pdf文件, 里面的演示效果和使用说明

与平常自己使用LaTeX不太一样的是, 使用本模板不需要怎么用到PatternRecognition.tex这个文件, 虽然这是主文件, 但内容已经被模块化了.

平常使用只需要更改YourFile文件夹中的文件并修改PatternRecognition.tex中的input语句即可

本模板兼容windows系统与linux系统, windows用户直接双击compile.bat即可,linux用户在本目录终端使用命令sh compile.sh

希望你也喜欢上LaTeX的方便与优雅
--Cosmo 2016-10-09
